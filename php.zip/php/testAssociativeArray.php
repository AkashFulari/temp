<?php
    // normal/ single dimentional array
    $a1 = array("akash","omkar","rohit"); // array starts from 0(index) and ends with(n-1)
    
    // how to change value of specific index value in array
    $a1[1]="Adling Omkar";

    // how to accethe array values 
    echo $a1[1];
    
    
    
    
    // associative array
    $student = array("rollno"=>"01","name"=>"Adling Omkar","Email":"omkar1212@gmail.com");
    
    // how to change value of specific index value in array
        //$a1[1]="Adling Omkar";
        $a1["name"]="Adling Omkar";

    // how to accethe array values 
        //echo $a1[1];
        echo $a1["email"];
    
    
?>