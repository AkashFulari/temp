<?php
    echo"<h1>About My Self:</h1>";
    echo "My name is Adling Omkar";
?>

<form method="post" action="getData.php">
    <input type="text" name="name" placeholder="Enter your name"/>
    <input type="email" name="email" placeholder="Enter your email"/>
    <input type="password" name="pass" placeholder="Enter your password"/>
    <input type="submit" value="sign In"/>
</form>
