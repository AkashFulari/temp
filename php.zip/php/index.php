<?php
    // this line connects the connection to the database to the php environment
    $con = mysqli_connect("localhost","root","","society") or die("MSQL Connection Error");
    if($con)
        echo"Connection Success<br/>";


    // how to show the data from the database
        // mysqli_query($con,YOUR_SQL_QUERY);
    $data = mysqli_query($con,"SELECT * FROM `members` where `name`='Adling Omkar'");

    $d = mysqli_fetch_assoc($data); // it returns the associative array of a query result

    //$d = mysqli_fetch_array($data); // it returns the array of a query result
    echo $d['email']."<br/>";

    echo "My name is Adling Omkar";
?>