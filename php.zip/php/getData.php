<?php
    //how to get the url parameters in php using GET Method
        //$email = $_GET['name'];


    //how to get the url parameters in php using POST Method
        //$email = $_POST['name'];


        
    //how to get the url parameters in php using REQUEST Method
        //$email = $_REQUEST['name'];


    echo $_POST['name']."<br/>";
    echo $_POST['email']."<br/>";
    echo $_POST['pass']."<br/>";


?>