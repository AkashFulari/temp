<?php
$a=10;
$b=20;
echo $a;
echo "<br>";
echo ("a+b=".$a+$b);
echo "<br>";

function add(){
    global $a,$b,$c;
    $c = $a + $b;
}
add();
echo $c;


?>
